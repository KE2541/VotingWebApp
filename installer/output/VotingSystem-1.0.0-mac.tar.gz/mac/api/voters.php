<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

mysqli_report(MYSQLI_REPORT_OFF);

set_error_handler(function ($severity, $message, $file, $line) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $message]);
    exit;
});

register_shutdown_function(function () {
    $error = error_get_last();
    if ($error && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
        ob_clean();
        http_response_code(500);
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'Fatal error: ' . $error['message']]);
    }
});

require_once __DIR__ . '/../config/database.php';

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'OPTIONS') {
    http_response_code(200);
    exit;
}

if ($method === 'GET') {
    session_start();
    if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Unauthorized']);
        exit;
    }
    session_write_close();

    $result = $conn->query("SELECT id, full_name, voter_id, has_voted, face_image, face_descriptor, location_lat, location_lng, device_info, ip_address, created_at FROM voters ORDER BY created_at DESC");
    if (!$result) { http_response_code(500); echo json_encode(['success' => false, 'message' => $conn->error]); exit; }
    $voters = $result->fetch_all(MYSQLI_ASSOC);
    echo json_encode(['success' => true, 'voters' => $voters]);
    exit;
}

if ($method === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $action = $data['action'] ?? '';

    if ($action === 'register') {
        session_start();
        if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
            http_response_code(401);
            echo json_encode(['success' => false, 'message' => 'Unauthorized']);
            exit;
        }

        $full_name = trim($data['full_name'] ?? '');
        $voter_id = trim($data['voter_id'] ?? '');
        $face_image = $data['face_image'] ?? null;
        $face_descriptor = $data['face_descriptor'] ?? null;
        $location_lat = isset($data['location_lat']) ? floatval($data['location_lat']) : null;
        $location_lng = isset($data['location_lng']) ? floatval($data['location_lng']) : null;
        $device_info = $data['device_info'] ?? null;
        $ip_address = $_SERVER['REMOTE_ADDR'] ?? null;

        if (empty($full_name) || empty($voter_id)) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Full name and voter ID are required']);
            exit;
        }

        if (!preg_match('/^(?:\d{6,9}|[A-Za-z]\d{7})$/', $voter_id)) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Voter ID must be 6-9 digit National ID or Passport (1 letter + 7 digits)']);
            exit;
        }

        $stmt = $conn->prepare("SELECT id FROM voters WHERE voter_id = ?");
        if (!$stmt) { http_response_code(500); echo json_encode(['success' => false, 'message' => $conn->error]); exit; }
        $stmt->bind_param("s", $voter_id);
        $stmt->execute();
        if ($stmt->get_result()->fetch_assoc()) {
            echo json_encode(['success' => false, 'message' => 'Voter ID already registered']);
            exit;
        }

        $stmt = $conn->prepare("INSERT INTO voters (full_name, voter_id, face_image, face_descriptor, location_lat, location_lng, device_info, ip_address) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        if (!$stmt) { http_response_code(500); echo json_encode(['success' => false, 'message' => $conn->error]); exit; }
        $stmt->bind_param("ssssddss", $full_name, $voter_id, $face_image, $face_descriptor, $location_lat, $location_lng, $device_info, $ip_address);

        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Voter registered successfully', 'voter' => ['id' => $stmt->insert_id, 'full_name' => $full_name, 'voter_id' => $voter_id]]);
        } else {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Registration failed: ' . $stmt->error]);
        }
        exit;
    }

    $voter_id = trim($data['voter_id'] ?? '');
    if (empty($voter_id)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Voter ID is required']);
        exit;
    }

    if (!preg_match('/^(?:\d{6,9}|[A-Za-z]\d{7})$/', $voter_id)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Invalid format. Use 6-9 digit National ID or Passport (1 letter + 7 digits).']);
        exit;
    }

    $stmt = $conn->prepare("SELECT id, full_name, voter_id, has_voted, face_image, face_descriptor FROM voters WHERE voter_id = ?");
    if (!$stmt) { http_response_code(500); echo json_encode(['success' => false, 'message' => $conn->error]); exit; }
    $stmt->bind_param("s", $voter_id);
    $stmt->execute();
    $voter = $stmt->get_result()->fetch_assoc();

    if ($voter) {
        echo json_encode(['success' => true, 'message' => 'Voter verified', 'voter' => $voter]);
    } else {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Voter not found.']);
    }
    exit;
}

if ($method === 'DELETE') {
    session_start();
    if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Unauthorized']);
        exit;
    }

    $data = json_decode(file_get_contents('php://input'), true);
    $id = intval($data['id'] ?? 0);

    if ($id === 0) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Voter ID is required']);
        exit;
    }

    $stmt = $conn->prepare("DELETE FROM voters WHERE id = ?");
    if (!$stmt) { http_response_code(500); echo json_encode(['success' => false, 'message' => $conn->error]); exit; }
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Voter removed successfully']);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Failed to remove voter']);
    }
    exit;
}

http_response_code(405);
echo json_encode(['success' => false, 'message' => 'Method not allowed']);

<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

require_once __DIR__ . '/../config/database.php';

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'OPTIONS') {
    http_response_code(200);
    exit;
}

if ($method !== 'GET') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$q = trim($_GET['q'] ?? '');

if (empty($q)) {
    echo json_encode(['success' => true, 'results' => []]);
    exit;
}

$search = '%' . $q . '%';

$stmt = $conn->prepare("
    SELECT c.id, c.name AS candidate_name, c.party, c.location,
           p.name AS position_name, p.`level`
    FROM candidates c
    JOIN positions p ON c.position_id = p.id
    WHERE c.location LIKE ?
    ORDER BY p.display_order, c.name
");
$stmt->bind_param("s", $search);
$stmt->execute();
$results = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

echo json_encode(['success' => true, 'results' => $results]);

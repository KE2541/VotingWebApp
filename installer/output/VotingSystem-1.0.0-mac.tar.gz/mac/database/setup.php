<?php
require_once __DIR__ . '/../config/database.php';

$conn->query("
    CREATE TABLE IF NOT EXISTS `positions` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `name` VARCHAR(100) NOT NULL UNIQUE,
        `display_order` INT DEFAULT 0,
        `level` VARCHAR(50) DEFAULT ''
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");

$conn->query("
    CREATE TABLE IF NOT EXISTS `candidates` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `name` VARCHAR(200) NOT NULL,
        `position_id` INT NOT NULL,
        `party` VARCHAR(200) DEFAULT '',
        `photo_url` VARCHAR(500) DEFAULT '',
        `bio` TEXT DEFAULT '',
        `location` VARCHAR(200) DEFAULT '',
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (`position_id`) REFERENCES `positions`(`id`) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");

$conn->query("
    CREATE TABLE IF NOT EXISTS `voters` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `full_name` VARCHAR(200) NOT NULL,
        `voter_id` VARCHAR(50) NOT NULL UNIQUE,
        `has_voted` TINYINT(1) DEFAULT 0,
        `face_image` LONGTEXT DEFAULT NULL,
        `face_descriptor` TEXT DEFAULT NULL,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");

$conn->query("
    CREATE TABLE IF NOT EXISTS `votes` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `voter_id` INT NOT NULL,
        `candidate_id` INT NOT NULL,
        `position_id` INT NOT NULL,
        `location_lat` DECIMAL(10,7) DEFAULT NULL,
        `location_lng` DECIMAL(10,7) DEFAULT NULL,
        `device_info` TEXT DEFAULT NULL,
        `ip_address` VARCHAR(45) DEFAULT NULL,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (`voter_id`) REFERENCES `voters`(`id`) ON DELETE CASCADE,
        FOREIGN KEY (`candidate_id`) REFERENCES `candidates`(`id`) ON DELETE CASCADE,
        FOREIGN KEY (`position_id`) REFERENCES `positions`(`id`) ON DELETE CASCADE,
        UNIQUE KEY `unique_voter_position` (`voter_id`, `position_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");

$conn->query("
    CREATE TABLE IF NOT EXISTS `election_settings` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `start_time` DATETIME NOT NULL,
        `end_time` DATETIME NOT NULL,
        `is_active` TINYINT(1) DEFAULT 1,
        `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");

$positions = [
    ['name' => 'President', 'level' => 'National (Kenya)'],
    ['name' => 'Governor', 'level' => 'County'],
    ['name' => 'Senator', 'level' => 'County'],
    ['name' => 'Women Rep', 'level' => 'County'],
    ['name' => 'MP', 'level' => 'Constituency'],
    ['name' => 'MCA', 'level' => 'Ward']
];
$stmt = $conn->prepare("INSERT IGNORE INTO `positions` (`name`, `display_order`, `level`) VALUES (?, ?, ?)");
foreach ($positions as $i => $pos) {
    $order = $i + 1;
    $stmt->bind_param("sis", $pos['name'], $order, $pos['level']);
    $stmt->execute();
}

$check = $conn->query("SELECT COUNT(*) as c FROM election_settings")->fetch_assoc();
if ($check['c'] == 0) {
    $conn->query("
        INSERT INTO `election_settings` (`start_time`, `end_time`, `is_active`)
        VALUES (NOW(), DATE_ADD(NOW(), INTERVAL 7 DAY), 1)
    ");
}

$r1 = $conn->query("SHOW COLUMNS FROM voters LIKE 'face_image'");
if ($r1->num_rows == 0) {
    $conn->query("ALTER TABLE voters ADD COLUMN face_image LONGTEXT DEFAULT NULL");
} else {
    $colInfo = $r1->fetch_assoc();
    if (stripos($colInfo['Type'], 'longtext') === false) {
        $conn->query("ALTER TABLE voters MODIFY COLUMN face_image LONGTEXT DEFAULT NULL");
    }
}
$r2 = $conn->query("SHOW COLUMNS FROM voters LIKE 'face_descriptor'");
if ($r2->num_rows == 0) {
    $conn->query("ALTER TABLE voters ADD COLUMN face_descriptor MEDIUMTEXT DEFAULT NULL");
} else {
    $col2 = $r2->fetch_assoc();
    if (stripos($col2['Type'], 'mediumtext') === false) {
        $conn->query("ALTER TABLE voters MODIFY COLUMN face_descriptor MEDIUMTEXT DEFAULT NULL");
    }
}

$r3 = $conn->query("SHOW COLUMNS FROM positions LIKE 'level'");
if ($r3->num_rows == 0) {
    $conn->query("ALTER TABLE positions ADD COLUMN `level` VARCHAR(50) DEFAULT ''");
    $conn->query("UPDATE positions SET `level` = 'National (Kenya)' WHERE name = 'President'");
    $conn->query("UPDATE positions SET `level` = 'County' WHERE name IN ('Governor', 'Senator', 'Women Rep')");
    $conn->query("UPDATE positions SET `level` = 'Constituency' WHERE name = 'MP'");
    $conn->query("UPDATE positions SET `level` = 'Ward' WHERE name = 'MCA'");
}

$r4 = $conn->query("SHOW COLUMNS FROM candidates LIKE 'location'");
if ($r4->num_rows == 0) {
    $conn->query("ALTER TABLE candidates ADD COLUMN `location` VARCHAR(200) DEFAULT ''");
}

$r5 = $conn->query("SHOW COLUMNS FROM votes LIKE 'location_lat'");
if ($r5->num_rows == 0) {
    $conn->query("ALTER TABLE votes ADD COLUMN `location_lat` DECIMAL(10,7) DEFAULT NULL AFTER `position_id`");
    $conn->query("ALTER TABLE votes ADD COLUMN `location_lng` DECIMAL(10,7) DEFAULT NULL AFTER `location_lat`");
    $conn->query("ALTER TABLE votes ADD COLUMN `device_info` TEXT DEFAULT NULL AFTER `location_lng`");
    $conn->query("ALTER TABLE votes ADD COLUMN `ip_address` VARCHAR(45) DEFAULT NULL AFTER `device_info`");
}

$r6 = $conn->query("SHOW COLUMNS FROM voters LIKE 'location_lat'");
if ($r6->num_rows == 0) {
    $conn->query("ALTER TABLE voters ADD COLUMN `location_lat` DECIMAL(10,7) DEFAULT NULL AFTER `face_descriptor`");
    $conn->query("ALTER TABLE voters ADD COLUMN `location_lng` DECIMAL(10,7) DEFAULT NULL AFTER `location_lat`");
    $conn->query("ALTER TABLE voters ADD COLUMN `device_info` TEXT DEFAULT NULL AFTER `location_lng`");
    $conn->query("ALTER TABLE voters ADD COLUMN `ip_address` VARCHAR(45) DEFAULT NULL AFTER `device_info`");
}

$r7 = $conn->query("SELECT COUNT(*) AS cnt FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE CONSTRAINT_SCHEMA = DATABASE() AND TABLE_NAME = 'candidates' AND CONSTRAINT_TYPE = 'UNIQUE' AND CONSTRAINT_NAME = 'unique_candidate_position'");
$row7 = $r7->fetch_assoc();
if ($row7['cnt'] == 0) {
    $r7a = $conn->query("SELECT COUNT(*) AS dup FROM candidates c1 INNER JOIN candidates c2 ON c1.name = c2.name AND c1.position_id = c2.position_id AND c1.id != c2.id");
    $dup = $r7a->fetch_assoc();
    if ($dup['dup'] == 0) {
        $conn->query("ALTER TABLE candidates ADD CONSTRAINT unique_candidate_position UNIQUE (name, position_id)");
    }
}

$r8 = $conn->query("SHOW COLUMNS FROM candidates LIKE 'party_symbol'");
if ($r8->num_rows == 0) {
    $conn->query("ALTER TABLE candidates ADD COLUMN `party_symbol` VARCHAR(500) DEFAULT '' AFTER `photo_url`");
}

$indexes = [
    'idx_votes_voter_id' => ['table' => 'votes', 'cols' => 'voter_id'],
    'idx_votes_candidate_id' => ['table' => 'votes', 'cols' => 'candidate_id'],
    'idx_votes_position_id' => ['table' => 'votes', 'cols' => 'position_id'],
    'idx_voters_voter_id' => ['table' => 'voters', 'cols' => 'voter_id'],
    'idx_candidates_position_id' => ['table' => 'candidates', 'cols' => 'position_id']
];
foreach ($indexes as $name => $idx) {
    $r = $conn->query("SHOW INDEX FROM `{$idx['table']}` WHERE Key_name = '$name'");
    if ($r && $r->num_rows == 0) {
        $conn->query("CREATE INDEX `$name` ON `{$idx['table']}` ({$idx['cols']})");
    }
}

echo json_encode(['success' => true, 'message' => 'Database setup complete']);
